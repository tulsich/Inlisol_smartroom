import React from "react";
import logo from "../assets/inlisol_logo.jpg";

function Icon({ name }) {
  const style = { width: 18, height: 18, display: "inline-block" };
  if (name === "dash") return <span style={style}>📊</span>;
  if (name === "events") return <span style={style}>🗂️</span>;
  if (name === "settings") return <span style={style}>⚙️</span>;
  return <span style={style}>•</span>;
}

export default function Sidebar({ route, onRouteChange }) {
  return (
    <aside className="sidebar">
      {/* LOGO + BRAND */}
      <div className="brandBlock" style={{ alignItems: "center" }}>
        <img
          src={logo}
          alt="Inlisol logo"
          style={{
            width: 64,
            height: 64,
            objectFit: "contain",
            marginBottom: 10,
          }}
        />
        <div className="brandTitle">Inlisol Smart Room</div>
        <div className="brandSub">Live health monitoring</div>
      </div>

      {/* NAV */}
      <div className="nav">
        <button
          className={`navItem ${route === "dashboard" ? "navItemActive" : ""}`}
          onClick={() => onRouteChange("dashboard")}
        >
          <Icon name="dash" />
          Dashboard
        </button>

        <button
          className={`navItem ${route === "events" ? "navItemActive" : ""}`}
          onClick={() => onRouteChange("events")}
        >
          <Icon name="events" />
          Events
        </button>

        <button
          className={`navItem ${route === "settings" ? "navItemActive" : ""}`}
          onClick={() => onRouteChange("settings")}
        >
          <Icon name="settings" />
          Settings
        </button>
      </div>

      <div />

      {/* FOOTER */}
      <div className="sidebarFooter">
        <div><b>INLISOL</b></div>
        <div className="muted">Prototype dashboard</div>
      </div>
    </aside>
  );
}
