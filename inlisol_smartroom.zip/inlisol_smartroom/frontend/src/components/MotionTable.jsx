import React from "react";

export default function MotionTable({ rows }) {
  return (
    <div className="tableWrap">
      <table className="table">
        <thead>
          <tr>
            <th>Target</th>
            <th>X</th>
            <th>Y</th>
            <th>Z</th>
            <th>Velocity</th>
            <th>Last seen</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td><b>{r.target}</b></td>
              <td>{r.x}</td>
              <td>{r.y}</td>
              <td>{r.z}</td>
              <td>{r.v}</td>
              <td>{r.t}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
