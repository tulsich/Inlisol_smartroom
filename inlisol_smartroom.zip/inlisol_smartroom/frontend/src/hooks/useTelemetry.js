import { useEffect, useState } from "react";
import { fetchLatestTelemetry } from "../api/telemetry";

export function useTelemetry(intervalMs = 3000) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let timer;

    const load = async () => {
      try {
        const res = await fetchLatestTelemetry();
        setData(res);
        setError(null);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    load(); // first load
    timer = setInterval(load, intervalMs);

    return () => clearInterval(timer);
  }, [intervalMs]);

  return { data, loading, error };
}
