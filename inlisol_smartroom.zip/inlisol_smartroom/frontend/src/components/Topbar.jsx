import React, { useState } from "react";

export default function Topbar({ title }) {
  const [q, setQ] = useState("");

  return (
    <div className="topbar">
      <div className="topbarLeft">
        <div className="pageTitle">{title}</div>
        <div className="pageHint">Modern dashboard mockup, data wiring later</div>
      </div>

      <div className="searchBox">
        <span style={{ opacity: 0.7 }}>🔎</span>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search person, event, device"
        />
      </div>
    </div>
  );
}
