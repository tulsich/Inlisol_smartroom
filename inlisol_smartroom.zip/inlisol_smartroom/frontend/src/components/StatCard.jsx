import React from "react";

export default function StatCard({ label, value, hint, status }) {
  const badgeClass =
    status === "good"
      ? "badge badgeGood"
      : status === "warn"
      ? "badge badgeWarn"
      : status === "bad"
      ? "badge badgeBad"
      : "badge";

  const badgeText =
    status === "good" ? "Normal" : status === "warn" ? "Attention" : status === "bad" ? "Alert" : "Info";

  return (
    <div className="statCard">
      <div className="statTop">
        <div className="statLabel">{label}</div>
        <div className={badgeClass}>{badgeText}</div>
      </div>
      <div className="statValue">{value}</div>
      <div className="statHint">{hint}</div>
    </div>
  );
}
