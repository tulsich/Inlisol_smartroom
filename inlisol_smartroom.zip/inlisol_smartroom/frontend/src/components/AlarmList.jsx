import React from "react";

function Badge({ level }) {
  const cls =
    level === "high"
      ? "badge badgeBad"
      : level === "medium"
      ? "badge badgeWarn"
      : "badge badgeGood";
  const text = level === "high" ? "High" : level === "medium" ? "Medium" : "Low";
  return <span className={cls}>{text}</span>;
}

export default function AlarmList({ alarms }) {
  return (
    <div className="sectionGap">
      {alarms.map((a) => (
        <div key={a.id} className="alarmItem">
          <div className="alarmRow">
            <div className="alarmTitle">{a.title}</div>
            <Badge level={a.level} />
          </div>
          <div className="alarmMeta">
            {a.person} · {a.time}
          </div>
          <div className="alarmMeta">{a.desc}</div>
        </div>
      ))}
    </div>
  );
}
