import React, { useState } from "react";

export default function Settings() {
  const [demoMode, setDemoMode] = useState(true);
  const [refresh, setRefresh] = useState(2);

  return (
    <div className="grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
      <div className="card">
        <div className="cardHeader">
          <div className="cardTitle">Dashboard settings</div>
          <span className="badge">UI</span>
        </div>
        <div className="cardBody">
          <div className="sectionGap">
            <div className="alarmItem">
              <div className="alarmRow">
                <div className="alarmTitle">Demo mode</div>
                <button
                  className={`pill ${demoMode ? "pillOn" : ""}`}
                  onClick={() => setDemoMode((s) => !s)}
                >
                  {demoMode ? "Enabled" : "Disabled"}
                </button>
              </div>
              <div className="alarmMeta">Use mock data for presentations</div>
            </div>

            <div className="alarmItem">
              <div className="alarmRow">
                <div className="alarmTitle">Refresh interval</div>
                <span className="badge">{refresh}s</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={refresh}
                onChange={(e) => setRefresh(Number(e.target.value))}
                style={{ width: "100%" }}
              />
              <div className="alarmMeta">Later used for polling /api/latest</div>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="cardHeader">
          <div className="cardTitle">Alarm thresholds</div>
          <span className="badge">Rules</span>
        </div>
        <div className="cardBody">
          <div className="sectionGap">
            <div className="alarmItem">
              <div className="alarmRow">
                <div className="alarmTitle">Heart rate high</div>
                <span className="badge badgeBad">120</span>
              </div>
              <div className="alarmMeta">Per person mapping coming next</div>
            </div>

            <div className="alarmItem">
              <div className="alarmRow">
                <div className="alarmTitle">Breath rate low</div>
                <span className="badge badgeWarn">10</span>
              </div>
              <div className="alarmMeta">Attach to person or target id</div>
            </div>

            <div className="alarmItem">
              <div className="alarmRow">
                <div className="alarmTitle">Multiple person</div>
                <span className="badge badgeGood">count &gt; 1</span>
              </div>
              <div className="alarmMeta">Main goal: multi person room monitoring</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
