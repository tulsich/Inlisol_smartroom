import React, { useMemo, useState } from "react";
import Sidebar from "./components/Sidebar.jsx";
import Topbar from "./components/Topbar.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Events from "./pages/Events.jsx";
import Settings from "./pages/Settings.jsx";

export default function App() {
  const [route, setRoute] = useState("dashboard");

  const title = useMemo(() => {
    if (route === "dashboard") return "Dashboard";
    if (route === "events") return "Events";
    if (route === "settings") return "Settings";
    return "Dashboard";
  }, [route]);

  return (
    <div className="appShell">
      <Sidebar route={route} onRouteChange={setRoute} />
      <div className="appMain">
        <Topbar title={title} />

        <div className="content">
          {route === "dashboard" && <Dashboard />}
          {route === "events" && <Events />}
          {route === "settings" && <Settings />}
        </div>

        <div className="footerBar">
          <div className="footerLeft">
            <span className="dotLive" />
            Live Feed
          </div>
          <div className="footerRight">
            <span className="muted">Inlisol Smart Room</span>
          </div>
        </div>
      </div>
    </div>
  );
}
