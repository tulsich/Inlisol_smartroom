import React, { useMemo } from "react";

export default function Events() {
  const rows = useMemo(() => {
    return [
      { id: "e1", type: "PeopleEvent", person: "Person 2", detail: "High HR spike", time: "Today 13:41" },
      { id: "e2", type: "PeopleEvent", person: "Person 1", detail: "Low BR near threshold", time: "Today 13:35" },
      { id: "e3", type: "System", person: "-", detail: "Device connected", time: "Today 12:58" },
    ];
  }, []);

  return (
    <div className="card">
      <div className="cardHeader">
        <div className="cardTitle">Events</div>
        <span className="badge">Log</span>
      </div>
      <div className="cardBody">
        <div className="tableWrap">
          <table className="table">
            <thead>
              <tr>
                <th>Type</th>
                <th>Person</th>
                <th>Detail</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td><b>{r.type}</b></td>
                  <td>{r.person}</td>
                  <td>{r.detail}</td>
                  <td>{r.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{ marginTop: 12 }} className="muted">
          This is mock data for prototype demo. We will wire real ThingsBoard events after backend is stable.
        </div>
      </div>
    </div>
  );
}
