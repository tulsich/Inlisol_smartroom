const API_BASE = "http://localhost:5050";

export const mockTelemetry = {
  peopleCount: 2,
  multiplePersonAlert: false,

  persons: [
    {
      id: "Person 1",
      heartRate: 75,
      breathRate: 16,
      posture: "Standing",
      status: "Normal",
    },
    {
      id: "Person 2",
      heartRate: 102,
      breathRate: 22,
      posture: "Sitting",
      status: "Attention",
    },
  ],

  targets: [
    {
      id: "t1",
      x: 4.018,
      y: 4.213,
      z: 0.377,
      velocity: 0.0,
      lastSeen: "Just now",
    },
    {
      id: "t2",
      x: 3.485,
      y: 2.831,
      z: 0.073,
      velocity: 0.0,
      lastSeen: "Just now",
    },
  ],

  alerts: [
    {
      type: "High heart rate",
      personId: "Person 2",
      message: "Heart rate above threshold",
    },
    {
      type: "Low breath rate",
      personId: "Person 1",
      message: "Breathing rate near lower bound",
    },
  ],
};

