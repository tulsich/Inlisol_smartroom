import React from "react";

export default function PersonVitals({ persons }) {
  return (
    <div className="tableWrap">
      <table className="table">
        <thead>
          <tr>
            <th>Person</th>
            <th>Heart rate</th>
            <th>Breath rate</th>
            <th>Posture</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {persons.map((p) => (
            <tr key={p.id}>
              <td><b>{p.name}</b></td>
              <td>{p.hr} bpm</td>
              <td>{p.br} rpm</td>
              <td>{p.posture}</td>
              <td>
                <span
                  className={
                    p.status === "Normal"
                      ? "badge badgeGood"
                      : p.status === "Attention"
                      ? "badge badgeWarn"
                      : "badge badgeBad"
                  }
                >
                  {p.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
