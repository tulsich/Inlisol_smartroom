import "./styles/dashboard.css";

export default function Dashboard() {
  return (
    <div className="dashboard-bg">
      {/* HEADER */}
      <header className="dashboard-header">
        <h1>Dashboard</h1>
        <p>Live health monitoring overview</p>
        <div className="time-tabs">
          <span className="active">1h</span>
          <span>4h</span>
          <span>12h</span>
          <span>24h</span>
        </div>
      </header>

      <div className="dashboard-grid">
        {/* MAIN */}
        <main className="dashboard-main">
          {/* VITALS */}
          <section className="glass-card">
            <h2>Vitals overview</h2>
            <div className="stats-row">
              <Stat title="People in room" value="2" status="normal" />
              <Stat title="Multiple person alert" value="False" status="normal" />
              <Stat title="Highest heart rate" value="102 bpm" status="attention" />
              <Stat title="Lowest breath rate" value="14 rpm" status="normal" />
            </div>
          </section>

          {/* PER PERSON */}
          <section className="glass-card">
            <h2>Per person vitals</h2>
            <table>
              <thead>
                <tr>
                  <th>Person</th>
                  <th>Heart rate</th>
                  <th>Breath rate</th>
                  <th>Posture</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Person 1</td>
                  <td>75 bpm</td>
                  <td>16 rpm</td>
                  <td>Standing</td>
                  <td><span className="pill normal">Normal</span></td>
                </tr>
                <tr>
                  <td>Person 2</td>
                  <td>102 bpm</td>
                  <td>22 rpm</td>
                  <td>Sitting</td>
                  <td><span className="pill attention">Attention</span></td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* MOTION TRACKING */}
          <section className="glass-card">
            <h2>Multi-person motion tracking</h2>
            <table>
              <thead>
                <tr>
                  <th>Target</th>
                  <th>X</th>
                  <th>Y</th>
                  <th>Z</th>
                  <th>Last seen</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>t1</td>
                  <td>4.018</td>
                  <td>4.213</td>
                  <td>0.377</td>
                  <td className="live">Just now</td>
                </tr>
                <tr>
                  <td>t2</td>
                  <td>3.485</td>
                  <td>2.831</td>
                  <td>0.073</td>
                  <td className="live">Just now</td>
                </tr>
              </tbody>
            </table>
          </section>
        </main>

        {/* ALERTS */}
        <aside className="dashboard-alerts">
          <h2>Alerts & alarms</h2>

          <Alert
            title="High heart rate"
            text="Person 2 · 2 min ago"
            type="danger"
          />

          <Alert
            title="Low breath rate"
            text="Person 1 · 7 min ago"
            type="warning"
          />

          <Alert
            title="Posture change"
            text="Standing → Sitting"
            type="info"
          />
        </aside>
      </div>
    </div>
  );
}

/* COMPONENTS */

function Stat({ title, value, status }) {
  return (
    <div className={`stat-card ${status}`}>
      <p>{title}</p>
      <h3>{value}</h3>
      <span className={`pill ${status}`}>{status}</span>
    </div>
  );
}

function Alert({ title, text, type }) {
  return (
    <div className={`alert-card ${type}`}>
      <strong>{title}</strong>
      <p>{text}</p>
    </div>
  );
}
